// pages/home/home.js
const app = getApp();
const innerAudioContext = wx.createInnerAudioContext()
const innerAudioContext2 = wx.createInnerAudioContext()

//获取数据库引用
const db = wx.cloud.database({ env: 'class-bluetooth-kuduw' });
Page({

  /**
   * 页面的初始数据
   */
  data: {
    stop: false,
    show5: false,
    action: '',
    age: '',
    height: '',
    status: '开始',
    resu:'',
    accXs: [],
    accYs: [],
    accZs: [],
    gyrXs: [],
    gyrYs: [],
    gyrZs: [],
    timeSs: [],
    startTime: 0,
    columns4: ['安卓', 'ios'],
    system: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setInnerAudioOption({ obeyMuteSwitch: false });
    innerAudioContext.src = 'https://6665-feicloud-g9886-1301103527.tcb.qcloud.la/1.mp3?sign=3ee22cb2158ab06ac16a98e56b936403&t=1589805705'
    innerAudioContext2.src = 'https://6665-feicloud-g9886-1301103527.tcb.qcloud.la/2.mp3?sign=533919194bde35a5c4bd0af3cdd72bd4&t=1589813045'

    
  },

  onConfirm4(event) {
    this.setData({
      show5: false,
      system: event.detail.value
    });
  },

  onCancel(event) {
    this.setData({
      show5: false
    });
  },

  onClose(event) {
    this.setData({
      show5: false
    });
  },

  showPopup4() {
    this.setData({ show5: true });
  },

  jump1() {
    wx.navigateTo({
      url: '/pages/squat/squat',
    })
  },

  jump2() {
    wx.navigateTo({
      url: '/pages/jump/jump',
    })
  },

  jump3() {
    wx.navigateTo({
      url: '/pages/prone/prone',
    })
  },

  jump4() {
    wx.navigateTo({
      url: '/pages/climb/climb',
    })
  },

  onbutton: function (event) {
    let _this = this;
    let accXs = [];
    let accYs = [];
    let accZs = [];
    let timeSs = [];
    let gyrXs = [];
    let gyrYs = [];
    let gyrZs = [];
    if (this.data.system){
      this.setData({
      startTime: new Date().getTime(),
      status: '采集中',
    })
      if (this.data.system == '安卓') {
        wx.startAccelerometer({
          interval: 'ui',
          success: res => { console.log("加速度计调用成功"); },
          fail: res => { console.log(res) }
        });
        wx.startGyroscope({
          interval: 'ui',
          success: res => { console.log("陀螺仪调用成功"); },
          fail: res => { console.log(res) }
        });
      }
      else {
        wx.startAccelerometer({
          interval: 'game',
          success: res => { console.log("加速度计调用成功"); },
          fail: res => { console.log(res) }
        });
        wx.startGyroscope({
          interval: 'game',
          success: res => { console.log("陀螺仪调用成功"); },
          fail: res => { console.log(res) }
        });
      }

      // 监听加速度数据
      innerAudioContext.play()
      wx.onAccelerometerChange(function (res) {
        let mid_time = new Date().getTime();
        let timeStep = (mid_time - _this.data.startTime) / 1000
        if ((timeStep > 5.5) && (timeStep <= 35.5)) {
          accXs.push(res.x)
          accYs.push(res.y)
          accZs.push(res.z)
          timeSs.push(mid_time)
        }
      })
      wx.onGyroscopeChange(function (res) {
        let mid_time = new Date().getTime();
        let timeStep = (mid_time - _this.data.startTime) / 1000
        if ((timeStep > 5.5) && (timeStep <= 35.5)) {
          gyrXs.push(res.x)
          gyrYs.push(res.y)
          gyrZs.push(res.z)
        }
        else if ((timeStep > 35.5) && (timeStep < 36)) {
          innerAudioContext2.play();
          _this.stop();
          _this.setData({
            stop: true,
            status: '开始',
            show4: true,
            accXs: accXs,
            accYs: accYs,
            accZs: accZs,
            gyrXs: gyrXs,
            gyrYs: gyrYs,
            gyrZs: gyrZs,
            timeSs: timeSs
          })
        }
      })
    }
    else {
      wx.showToast({
        title: '请先完善信息',
        icon: 'none'
      })
    }
  },


  stop: function () {
    wx.stopAccelerometer({
      success: res => {
        console.log("停止读取加速度")
      }
    })
    wx.stopGyroscope({
      success: res => {
        console.log("停止读取陀螺仪")
      }
    })
  },


  abandon: function () {
    wx.stopAccelerometer({
      success: res => {
        console.log("停止读取加速度")
      }
    })
    wx.stopGyroscope({
      success: res => {
        console.log("停止读取陀螺仪")
      }
    })
    this.setData({
      status: '开始',
      show4: false,
    })
  },



  verify: function(){
    wx.showToast({
      icon: 'loading',
      duration: 5000
    })
    console.log("save...")

    let accXs = this.data.accXs
    let accYs = this.data.accYs
    let accZs = this.data.accZs
    let gyrXs = this.data.gyrXs
    let gyrYs = this.data.gyrYs
    let gyrZs = this.data.gyrZs
    var _this = this

    wx.request({
      url: 'http://49.234.75.229:5000/',
      data: {
        accXs: JSON.stringify(accXs),
        accYs: JSON.stringify(accYs),
        accZs: JSON.stringify(accZs),
        gyrXs: JSON.stringify(gyrXs),
        gyrYs: JSON.stringify(gyrYs),
        gyrZs: JSON.stringify(gyrZs),
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        _this.setData({
          resu:res.data,
        })
        console.log(resu)
      },
      fail: function (res) {
        console.log('submit fail');
      }
    })

    this.setData({
      show4: false,
    })

  }
})